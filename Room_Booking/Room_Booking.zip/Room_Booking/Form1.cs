﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

//************************************************************
// Name: 王品力
// Class: 資管三
// SID: S06490040  
// Functions: 壽星訂房專案優惠系統練習
// Limitations: (1). 屬性的部分要用指令執行的方式 (2). ICON使用指令檔案載入的方式 (3).壽星生日當月入住房價打九折!
// Assignment: No.4
// Date: 2020/05/27
//************************************************************

namespace S06490040HW4
{
    public partial class Form1 : Form
    {
        String FilePath_icon = string.Empty;            //宣告字串變數FilePath_icon
        string what_date;                               //宣告字串變數what_date
        string what_zoom;                               //宣告字串變數what_zoom
        string what_period;                             //宣告字串變數what_perio
        int days;                                       //宣告整數變數days

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.Text = "壽星訂房優惠專案系統";         //將Form的標題改為指定內容

            DirectoryInfo dir = new DirectoryInfo(Application.StartupPath);                         //設定exe檔為路徑抓取的root
            FilePath_icon = dir.Parent.Parent.FullName + @"\birthday_icon\birthday_gift.ico";       //往上找找到要的icon檔案
            this.Icon = Icon.ExtractAssociatedIcon(FilePath_icon);                                  //將icon設為指定內容

            dateTimePicker1.MaxDate = DateTime.Today;   //設定生日日期的上限為當天
            monthCalendar1.MinDate = DateTime.Today;    //設定住房日期的下限為當天

            string[] zoomprice = new string[] { "標準雙人房3000元", "豪華雙人房4000元", "標準家庭房4000元", "豪華家庭房5000元" };   //宣告字串陣列用來裝房型價錢內容
            comboBox1.Items.AddRange(zoomprice);    //將陣列zoomprice的內容丟到comboBox1.Items裡面
            comboBox1.SelectedItem = zoomprice[0];  //將comboBox1的預設值設為陣列zoomprice的第一個

            label1.Text = "1.請輸入生日：";                          //設定label1的Text內容
            label2.Text = "2.請選擇房型：";                          //設定label2的Text內容
            label3.Text = "3.請選擇入住期間";                        //設定label3的Text內容
            label4.Text = "請先輸入生日，壽星當月入住房價打9折";     //設定label4的Text內容
            button1.Text = "確定";                                   //設定button1的Text內容
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            what_date = dateTimePicker1.Value.ToString("yyyy年M月d日");    //將dateTimePicker1的value抓下來轉成字串賦予給what_date
            label4.Text = "您的生日是" + what_date;                        //設定label4的Text內容
        }


        private void button1_Click(object sender, EventArgs e)
        {
            string strsum_price;                                        //宣告字串變數strsum_price
            string Msg;                                                 //宣告字串變數Msg
            double sum_price;                                           //宣告浮點數變數strsum_price
            string zoom_type = comboBox1.Text.Substring(0,5);           //將comboBox1.Text的前五個字元(房型)抓下來賦予給zoom_type
            string price = comboBox1.Text.Substring(5, 4);              //將comboBox1.Text的中後段4個字元(價錢)抓下來賦予給price

            if((what_period.Substring(5,1) == what_date.Substring(5,1)) || (what_period.Substring(15,1) == what_date.Substring(5,1)))  //當生日月份與入住期間月份相同時
            {
                sum_price = int.Parse(price) * days * 0.9;              //總金額打九折
                strsum_price = Convert.ToString(sum_price);             //將浮點數型態sum_price轉為字串型態
                Msg = "入住房型為：" + zoom_type + Environment.NewLine + Environment.NewLine +     //設定字串Msg的內容
                      "壽星入住房價打九折!" + Environment.NewLine + Environment.NewLine +
                      "入住天數為：" + days + Environment.NewLine + Environment.NewLine +
                      "房價總計為：" + strsum_price;
                label4.Text = Msg;                                      //設定label4的Text內容
            }
            else
            {
                sum_price = int.Parse(price) * days;                    //計算出總金額
                strsum_price = Convert.ToString(sum_price);             //將浮點數型態sum_price轉為字串型態
                Msg = "入住房型為：" + zoom_type + Environment.NewLine + Environment.NewLine +     //設定字串Msg的內容
                      "入住天數為：" + days + Environment.NewLine + Environment.NewLine +
                      "房價總計為：" + strsum_price;
                label4.Text = Msg;                                      //設定label4的Text內容
            }
        }

        private void comboBox1_SelectedValueChanged(object sender, EventArgs e)
        {
            what_zoom = comboBox1.Text;                    //將comboBox1.Text內容賦予給what_zoom
            label4.Text = "您選擇的房型是" + what_zoom;    //設定label4的Text內容
        }

        private void monthCalendar1_DateSelected(object sender, DateRangeEventArgs e)
        {
            DateTime ds = monthCalendar1.SelectionStart;    //選擇入住的起始日期
            DateTime de = monthCalendar1.SelectionEnd;      //選擇入住的結束日期
            TimeSpan ts = de - ds;                          //將入住的結束日期減去入住的起始日期
            days = ts.Days + 1;                             //將相減後的天數+1則為入住天數
            what_period = monthCalendar1.SelectionStart.ToString("yyyy/M/dd") + "~" +  //設定選擇入住期間的日期顯示
                monthCalendar1.SelectionEnd.ToString("yyyy/M/dd");
            label4.Text = "您入住日期為：" + what_period;   //設定label4的Text內容
        }
    }
}
