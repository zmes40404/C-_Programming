﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO; 

//************************************************************
// Name: 王品力
// Class: 資管三
// SID: S06490040  
// Functions: (1). 小綠人播放器練習 - 變換速度
// Limitations: (1). 圖片的部分要用imagelist載入的方式
//              (2). 每過10秒，小綠人會變快1倍速度
// Assignment: No.3
// Date: 2020/05/05
//************************************************************

namespace S06490040HW3
{
    public partial class Form1 : Form
    {
        String FilePath_icon = string.Empty;                    //宣告所需要使用的字串、整數、位元變數，有些給予初始值
        int counter, pasue_counter=0;                           //宣告所需要使用的字串、整數、位元變數，有些給予初始值
        byte counter_G = 0;                                     //宣告所需要使用的字串、整數、位元變數，有些給予初始值
        const int max_counter = 30;                             //宣告所需要使用的字串、整數、位元變數，有些給予初始值
        const byte MAX_Num_GreenWalkers = 18;                   //宣告所需要使用的字串、整數、位元變數，有些給予初始值

        //如果圖片引入imagelist用指令的方式，則定義下列字串變數，用來儲存路徑
            //String FilePath_btn_1 = string.Empty;
            //String FilePath_btn_2 = string.Empty;
            //String FilePath_btn_3 = string.Empty;


        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.Text = "小綠人播放練習 - 變換速度";                   //設定form名稱

            label1.Font = new Font("標楷體", 16, FontStyle.Bold);      //設定label1的字體內容與大小等
            label1.Text = "倒數秒數：";

            label2.Font = new Font("標楷體", 16, FontStyle.Bold);      //設定label2的字體內容與大小等
            label2.TextAlign = ContentAlignment.MiddleCenter;
            label2.BorderStyle = BorderStyle.FixedSingle;
            label2.Text = "";

            label3.Font = new Font("標楷體", 16, FontStyle.Bold);      //設定label3的字體內容與大小等
            label3.Text = "檔案名稱：";

            label4.Font = new Font("標楷體", 16, FontStyle.Bold);      //設定label4的字體內容與大小、背景顏色等
            label4.TextAlign = ContentAlignment.MiddleCenter;
            label4.BorderStyle = BorderStyle.FixedSingle;
            label4.BackColor = Color.Yellow;
            label4.ForeColor = Color.Blue;
            label4.Text = "";

            label5.Font = new Font("標楷體", 16, FontStyle.Bold);      //設定label5的字體內容與大小等
            label5.Text = "變換時間(毫秒/次)：";

            label6.Font = new Font("標楷體", 16, FontStyle.Bold);      //設定label6的字體內容與大小、背景顏色等
            label6.TextAlign = ContentAlignment.MiddleCenter;
            label6.BorderStyle = BorderStyle.FixedSingle;
            label6.BackColor = Color.Yellow;
            label6.ForeColor = Color.Blue;
            label6.Text = "";

            pictureBox1.BorderStyle = BorderStyle.Fixed3D;              //設定pictureBox1格子的特效

            this.Icon = Icon.FromHandle(((Bitmap)imageList3.Images[0]).GetHicon()); ;       //將form的Icon設為放在imagelist裡面的圖案

            //若Icon的抓取用路徑的方式，則為下列程式碼
                /*DirectoryInfo dir = new DirectoryInfo(Application.StartupPath);
                FilePath_icon = dir.Parent.Parent.FullName + @"\image\tra.ico";
                if (File.Exists(FilePath_icon))
                {
                    //取得 Icon 物件
                    Icon myIcon = Icon.FromHandle(new Bitmap(Image.FromFile(FilePath_icon)).GetHicon());
                    if (myIcon != null)
                    {
                        //設定表單 Icon
                        this.Icon = myIcon;
                    }
                }*/

            //若想用指令來把圖片放到imagelist裡面，則為下列程式碼
                /*FilePath_btn_1 = dir.Parent.Parent.FullName + @"\image\Pause.png";
                FilePath_btn_2 = dir_1.Parent.Parent.FullName + @"\PPS\Play.png";
                FilePath_btn_3 = dir_1.Parent.Parent.FullName + @"\PPS\Stop.png";
                Image Pause = Image.FromFile(FilePath_btn_1, true);
                ImageList1.Images.Add(Pause);
                Image Play = Image.FromFile(FilePath_btn_2,true);
                ImageList1.Images.Add(Play);
                Image Stop = Image.FromFile(FilePath_btn_3,true);
                ImageList1.Images.Add(Stop);*/

            button1.BackgroundImage = imageList2.Images[1];         //將按鈕的圖案預設為一個為播放另一個為停止
            button1.BackgroundImageLayout = ImageLayout.Zoom;       //設定將圖片剛好填滿按鈕的大小
            button2.BackgroundImage = imageList2.Images[2];
            button2.BackgroundImageLayout = ImageLayout.Zoom;

            timer1.Enabled = false;                                 //表單載入時timer1尚未開始計時
            timer2.Enabled = false;                                 //表單載入時timer2尚未開始計時

            counter = max_counter;                                  //將max_counter的值賦予給counter
        }

        private void button1_Click(object sender, EventArgs e)
        {
            pasue_counter++;                                        //pause_counter一次加一
            pasue_counter %= 2;                                     //將pause_counter的值設為pause_counter取2的餘數

            if (pasue_counter == 1)                                 //當pause_counter的值為1時
            {
                timer1.Enabled = true;                              //timer1開始計時
                timer2.Enabled = true;                              //timer2開始計時
                button1.BackgroundImage = imageList2.Images[0];     //將按鈕1的圖案設為暫停的圖案
                button1.BackgroundImageLayout = ImageLayout.Zoom;   //設定將圖片剛好填滿按鈕的大小
            }
            else                                                    //當pause_counter的值不為1時
            {
                timer1.Enabled = false;                             //timer1停止計時
                timer2.Enabled = false;                             //timer2停止計時
                button1.BackgroundImage = imageList2.Images[1];     //將按鈕1的圖案設為播放的圖案
                button1.BackgroundImageLayout = ImageLayout.Zoom;   //設定將圖片剛好填滿按鈕的大小
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();                                     //關閉程式
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            label2.Text = Convert.ToString(counter);                //將counter的值轉為字串賦予給label2的Text
            label2.Font = new Font("標楷體", 58, FontStyle.Bold);   //設定label2的字體大小與字型
            timer1.Interval = 1000;                                 //將timer1的變動時間設為1秒
            label6.Font = new Font("標楷體", 38, FontStyle.Bold);   //設定label6字體大小與字型

            if (counter > 20)                                       //當counter大於20
            {
                timer2.Interval = 50;                               //設定timer2的變動時間為50毫秒
                label6.Text = Convert.ToString(timer2.Interval);    //將timer2.Interval的值轉為字串賦予給label6的Text
                label2.BackColor = Color.Blue;                      //設定label2的背景顏色
                label2.ForeColor = Color.Yellow;                    //設定label2的字體顏色
                counter--;                                          //counter減一
            }
            else if(counter > 10)                                   //當counter大於10
            {
                timer2.Interval = 25;                               //設定timer2的變動時間為25毫秒
                label6.Text = Convert.ToString(timer2.Interval);    //將timer2.Interval的值轉為字串賦予給label6的Text
                label2.BackColor = Color.Green;                     //設定label2的背景顏色
                label2.ForeColor = Color.Purple;                    //設定label2的字體顏色
                counter--;                                          //counter減一
            }
            else if(counter > 1)                                    //當counter大於1
            {
                timer2.Interval = 12;                               //設定timer2的變動時間為12毫秒
                label6.Text = Convert.ToString(timer2.Interval);    //將timer2.Interval的值轉為字串賦予給label6的Text
                label2.BackColor = Color.Red;                       //設定label2的背景顏色
                label2.ForeColor = Color.Gray;                      //設定label2的字體顏色
                counter--;                                          //counter減一
            }
            else                                                    //if不為以上狀況時
            {
                counter = max_counter;                              //將counter的值設為max_counter的值
            }
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            byte tmp = 0;                                           //定義一個變數tmp
            string FileName = string.Empty;                         //定義一個空字串
            counter_G++;                                            //counter_G加一

            if(counter_G > MAX_Num_GreenWalkers)                    //當counter_G的值大於MAX_Num_GreenWalkers的值時
                counter_G %= MAX_Num_GreenWalkers;                  //將counter_G設為counter_g對MAX_Num_GreenWalker取餘數

            tmp = counter_G;                                        //將tmp的值設為counter_G的值

            if(counter_G < 10)                                      //當counter_G小於10時
            {
                FileName = "0" + tmp.ToString() + ".bmp";           //設定字串FileName的內容
            }
            else                                                    //當counter_G不為小於10時
            {
                FileName = tmp.ToString() + ".bmp";                 //設定字串FileName的內容
            }

            label4.Text = FileName;                                 //將FileName的內容賦予給label4的Text

            pictureBox1.Image = imageList1.Images[tmp-1];           //將imagelist裡面的圖片拿出給秀在pictureBox1上
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage; //將pictureBox1的大小設為與圖片的大小一致
        }
    }
}
//老師給的tips:
    //控制速度在tickvalue
    //當倒數至0時要修正成30 並變回慢速
    //2個timer 一個控小綠人同時控制檔案名稱  另一個控右邊的倒數秒數同時控制變換時間
