﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

//****************************************************************************************************************
// Name: 王品力
// Class: 資管三
// SID: S06490040  
// Functions: 影音視聽隨選播放
// Limitations: (1). 圖片會隨機選擇、定時更換、非同步更新 (2). 歌手與歌名以跑馬燈方式顯示
// Assignment: No.5
// Date: 2020/06/15
//*****************************************************************************************************************

namespace S06490040HW5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        String FilePath_root = String.Empty;                                //定義一個字串全域變數

        private void Form1_Load(object sender, EventArgs e)
        {
                       
            this.Text = "多媒體播放練習";                                   //設計基本的表單資料樣式
            button1.Font = new Font("標楷體", 24, FontStyle.Bold);
            button1.Text = "啟動";
            button2.Font = new Font("標楷體", 24, FontStyle.Bold);
            button2.Text = "結束";

            timer1.Enabled = true;                                          //timer1開始計時
            timer2.Enabled = true;                                          //timer2開始計時

            timer1.Interval = 1500;                                         //timer1的變動時間設為1.5秒
            timer2.Interval = 1400;                                         //timer2的變動時間設為1.4秒

            DirectoryInfo dir = new DirectoryInfo(Application.StartupPath); //設定基本的讀取路徑
            FilePath_root = dir.Parent.Parent.FullName + @"\videos\";       //將FilePath_root的內容設為程式執行檔到名為videos的資料夾的路徑
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            Random ran_p1 = new Random();                                   //建立一個亂數物件實體
            int FileIndex_p1, Previous_FileIndex_p1 = 0;                    //定義變數
            String FilePath_p1 = String.Empty;                              //定義字串變數
            String FileName_p1 = String.Empty;                              //定義字串變數

            do
            {
                FileIndex_p1 = ran_p1.Next(1, 4);                           //將變數FileIndex_p1的內容設為數字1~3中隨機產生一個數
            } while (FileIndex_p1 == Previous_FileIndex_p1);                //當FileIndex_p1的內容等於Previous_FileIndex_p1的內容時，執行迴圈

            Previous_FileIndex_p1 = FileIndex_p1;                           //將FileIndex_p1的內容賦予給Previous_FileIndex_p1

            switch (FileIndex_p1)
            {
                case 1:                                                     //當FileIndex_p1等於1時
                    FileName_p1 = "Jony J - 不用去猜  .jpg";                //指定FileName_p1的內容
                    break;
                case 2:                                                     //當FileIndex_p1等於2時
                    FileName_p1 = "Maroon 5 - Girls Like You  .jpg"; ;      //指定FileName_p1的內容
                    break;
                case 3:                                                     //當FileIndex_p1等於3時
                    FileName_p1 = "ZYAN - Dusk Till Dawn  .jpg";            //指定FileName_p1的內容
                    break;
                default:
                    break;
            }

            FilePath_p1 = FilePath_root + FileName_p1;                      //將路徑設為先前到videos資料夾的路徑再加上圖片檔名
            this.pictureBox1.Image = Image.FromFile(FilePath_p1);           //pictureBox1用路徑抓取圖片
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;         //將圖片大小設為與pictureBox1大小一樣
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            Random ran_p2 = new Random();                                   //建立一個亂數物件實體
            int FileIndex_p2, Previous_FileIndex_p2 = 0;                    //定義變數
            String FilePath_p2 = String.Empty;                              //定義字串變數
            String FileName_p2 = String.Empty;                              //定義字串變數

            do
            {
                FileIndex_p2 = ran_p2.Next(4, 7);                           //將變數FileIndex_p2的內容設為數字4~6中隨機產生一個數
            } while (FileIndex_p2 == Previous_FileIndex_p2);                //當FileIndex_p2的內容等於Previous_FileIndex_p2的內容時，執行迴圈

            Previous_FileIndex_p2 = FileIndex_p2;                           //將FileIndex_p2的內容賦予給Previous_FileIndex_p2

            switch (FileIndex_p2)
            {
                case 4:                                                     //當FileIndex_p2等於4時
                    FileName_p2 = "潘瑋柏 - 快樂崇拜  .jpg";                //指定FileName_p2的內容
                    break;
                case 5:                                                     //當FileIndex_p2等於5時
                    FileName_p2 = "高爾宣 - Without You  .jpg"; ;           //指定FileName_p2的內容
                    break;
                case 6:                                                     //當FileIndex_p2等於6時
                    FileName_p2 = "趙方婧 - 芒種  .jpg";                    //指定FileName_p2的內容
                    break;
                default:
                    break;
            }

            FilePath_p2 = FilePath_root + FileName_p2;                      //將路徑設為先前到videos資料夾的路徑再加上圖片檔名
            this.pictureBox2.Image = Image.FromFile(FilePath_p2);           //pictureBox2用路徑抓取圖片
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;         //將圖片大小設為與pictureBox2大小一樣

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form2 frm = new Form2();    //呼叫與顯示表單2
            frm.Show();
            this.Hide();                //隱藏表單
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();         //關閉程式
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();         //關閉程式
        }

        
    }
}
