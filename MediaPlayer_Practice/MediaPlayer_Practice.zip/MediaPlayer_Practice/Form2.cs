﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

//****************************************************************************************************************
// Name: 王品力
// Class: 資管三
// SID: S06490040  
// Functions: 影音視聽隨選播放
// Limitations: (1). 圖片會隨機選擇、定時更換、非同步更新 (2). 歌手與歌名以跑馬燈方式顯示
// Assignment: No.5
// Date: 2020/06/15
//*****************************************************************************************************************

namespace S06490040HW5
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private static int Previous_FileIndex = 0;                          //定義變數
        string tmpText = String.Empty;                                      //定義字串變數

        private void Form2_Load(object sender, EventArgs e)
        {
            const int MaxNumVideos = 6;                                     //定義整數變數並賦予初始值
            Random ranObj = new Random();                                   //建立一個亂數物件實體
            int FileIndex;                                                  //定義變數
            timer1.Enabled = true;                                          //timer1開始計時
            timer1.Interval = 200;                                          //timer1的變動時間設為0.2秒

            DirectoryInfo dir = new DirectoryInfo(Application.StartupPath); //設定基本的讀取路徑
            String FilePath = dir.Parent.Parent.FullName + "\\videos\\";    //將FilePath_root的內容設為程式執行檔到名為videos的資料夾的路徑
            String FileName = String.Empty;                                 //定義字串變數

            do
            {
                FileIndex = ranObj.Next(1, MaxNumVideos + 1);               //將變數FileIndex的內容設為數字1~6中隨機產生一個數
            } while (FileIndex == Previous_FileIndex);                      //當FileIndex的內容等於Previous_FileIndex的內容時，執行迴圈

            Previous_FileIndex = FileIndex;                                 //將FileIndex的內容賦予給Previous_FileIndex

            switch (FileIndex)
            {
                case 1:                                                     //當FileIndex等於1時
                    FileName = "Jony J - 不用去猜  .mp4";                   //指定FileName的內容
                    break;
                case 2:                                                     //當FileIndex等於2時
                    FileName = "Maroon 5 - Girls Like You  .mp4";           //指定FileName的內容
                    break;
                case 3:                                                     //當FileIndex等於3時
                    FileName = "ZAYN - Dusk Till Dawn  .mp4";               //指定FileName的內容
                    break;
                case 4:                                                     //當FileIndex等於4時
                    FileName = "高爾宣 - Without You  .mp4";                //指定FileName的內容
                    break;
                case 5:                                                     //當FileIndex等於5時
                    FileName = "趙方婧 - 芒種  .mp4";                       //指定FileName的內容
                    break;
                case 6:                                                     //當FileIndex等於6時
                    FileName = "潘瑋柏 - 快樂崇拜  .mp4";                   //指定FileName的內容
                    break;
                default:
                    break;
            }

            FilePath = FilePath + FileName;                                 //將路徑設為先前到videos資料夾的路徑再加上圖片檔名
            tmpText = FileName;                                             //將FileName的內容賦予給tmpText


            axWindowsMediaPlayer1.uiMode = "Full";                          //設定WindowsMediaPlayer的UIMODE

            axWindowsMediaPlayer1.URL = @FilePath;                          //影片檔案路徑
            axWindowsMediaPlayer1.settings.volume = 50;                     //WMP音量預設值 <min 0 ~ 100 max>
            axWindowsMediaPlayer1.settings.setMode("loop", true);           // 設定重複播放，可參考https://www.itdaan.com/tw/8b36adfeec9f0122d8c112285296d8f0
            axWindowsMediaPlayer1.Ctlcontrols.play();                       //開始播放影片            
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            string newst = tmpText.Substring(0, 1);                         //將tmpText內容的第一個字元切下來賦予給newst
            tmpText = tmpText.Substring(1, tmpText.Length - 1) + newst;     //將切下來的那個字元加到tmpText的字串減一個字元的最後面
            this.Text = tmpText;                                            //將tmpText設為標題
        }
        
        private void Form2_FormClosing(object sender, FormClosingEventArgs e)
        {
            axWindowsMediaPlayer1.Ctlcontrols.stop(); //停止播放影片

            Form1 frm = new Form1();   //呼叫與顯示表單1
            frm.Show();
            this.Hide();               //隱藏表單2 
        }

        private void Form2_Resize(object sender, EventArgs e)
        {
            axWindowsMediaPlayer1.Dock = System.Windows.Forms.DockStyle.Fill;   //設定影片的大小與size符合
            axWindowsMediaPlayer1.Size = this.Size;
        }
    }
}
